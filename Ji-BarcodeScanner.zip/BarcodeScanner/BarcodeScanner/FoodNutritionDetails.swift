//
//  FoodNutritionDetails.swift
//  BarcodeScanner
//
//  Created by Osman Balci on 6/3/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct FoodNutritionDetails: View {
   
    // Input Parameter passed by reference
    @Binding var barcode: String
   
    var body: some View {
        /*
         foodItem global variable was obtained in NutritionixApiData.swift
         A Form cannot have more than 10 Sections. Group the Sections if more than 10.
         */
        Form {
            Group {
                Section(header: Text("Brand Name")) {
                    Text(foodItem.brandName)
                }
                Section(header: Text("Food Name")) {
                    Text(foodItem.foodName)
                }
                Section(header: Text("Food Item Photo")) {
                    getImageFromUrl(url: foodItem.imageUrl)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                }
                Section(header: Text("Food Ingredients")) {
                    Text(foodItem.ingredients)
                }
                Section(header: Text("Serving Size")) {
                    Text("\(foodItem.servingQuantity) \(foodItem.servingUnit) (\(foodItem.servingWeight))")
                }
                Section(header: Text("Serving Size Calories")) {
                    Text(foodItem.calories)
                }
            }
            Group {
                Section(header: Text("Serving Size Dietary Fiber")) {
                    Text(foodItem.dietaryFiber)
                }
                Section(header: Text("Serving Size Protein")) {
                    Text(foodItem.protein)
                }
                Section(header: Text("Serving Size Saturated Fat")) {
                    Text(foodItem.saturatedFat)
                }
                Section(header: Text("Serving Size Sodium")) {
                    Text(foodItem.sodium)
                }
                Section(header: Text("Serving Size Sugars")) {
                    Text(foodItem.sugars)
                }
                Section(header: Text("Serving Size Total Carbohydrate")) {
                    Text(foodItem.totalCarbohydrate)
                }
                Section(header: Text("Serving Size Total Fat")) {
                    Text(foodItem.totalFat)
                }
            }
            Group {
                Section(header: Text("End of Nutrition Details")) {
                    Button(action: {
                        /*
                         Upon making ScanFoodBarcode's @State variable 'barcode' empty,
                         it invalidates its appearance and recomputes its body view
                         resulting in the display of the barcode scanning camera view
                         to enable another scan.
                         */
                        self.barcode = ""
                    }) {
                        HStack {
                            Image(systemName: "arrow.left.square.fill")
                                .imageScale(.large)
                                .font(Font.title.weight(.regular))
                            Text("Go Back")
                                .font(.headline)
                        }
                    }
                }
            }
 
        }   // End of Form
        .navigationBarTitle(Text("Nutrition Details"), displayMode: .inline)
        .navigationBarBackButtonHidden(true)
        .font(.system(size: 14))
    }
}
 
struct FoodNutritionDetails_Previews: PreviewProvider {
    static var previews: some View {
        FoodNutritionDetails(barcode: .constant(""))
    }
}
 
