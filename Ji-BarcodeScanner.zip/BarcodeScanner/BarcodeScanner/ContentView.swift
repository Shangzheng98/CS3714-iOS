//
//  ContentView.swift
//  BarcodeScanner
//
//  Created by Osman Balci on 5/26/20.
//  Copyright © 2020 Osman Balci. All rights reserved.
//
 
import SwiftUI
 
struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
               
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading) {
                    Image("BarcodeScanning")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                        .padding()
                   
                    NavigationLink(destination: ScanFoodBarcode()) {
                        HStack {
                            Image(systemName: "barcode.viewfinder")
                                .foregroundColor(.blue)
                                .imageScale(.large)
                                .font(Font.title.weight(.regular))
                                .frame(width: 60)
                            Text("Scan Food Barcode")
                                .font(.headline)
                        }
                    }.padding()
                   
                    NavigationLink(destination: EnterFoodBarcodeUPC()) {
                        HStack {
                            Image(systemName: "pencil.and.ellipsis.rectangle")
                                .foregroundColor(.blue)
                                .imageScale(.large)
                                .font(Font.title.weight(.regular))
                                .frame(width: 60)
                            Text("Enter Food Barcode Value")
                                .font(.headline)
                        }
                    }.padding()
                   
                    NavigationLink(destination: ScanQRBarcode()) {
                        HStack {
                            Image(systemName: "qrcode.viewfinder")
                                .foregroundColor(.blue)
                                .imageScale(.large)
                                .font(Font.title.weight(.regular))
                                .frame(width: 60)
                            Text("Scan QR Barcode")
                                .font(.headline)
                        }
                    }.padding()
                   
                    Text("Powered By")
                        .font(.headline)
                        .padding(.top, 30)
                        .padding(.horizontal, 30)
                   
                    // Show Nutritionix API provider's website in default web browser
                    Link(destination: URL(string: "https://www.nutritionix.com/business/api")!) {
                        Image("Nutritionix")
                            .renderingMode(.original)   // Keep the logo in its original form
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 37)
                            .padding(.horizontal, 30)
                    }
 
                }   // End of VStack
                    .navigationBarTitle(Text("Barcode Scanner"), displayMode: .inline)
                    .padding(50)
               
            }   // End of ScrollView
               
            }   // End of ZStack
           
        }   // End of NavigationView
            // Use single column navigation view for iPhone and iPad
            .navigationViewStyle(StackNavigationViewStyle())
       
    }
}
 
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
 
