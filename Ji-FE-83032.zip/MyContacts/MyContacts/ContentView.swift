//
//  ContentView.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            ContactsList()
                .tabItem {
                    Image(systemName: "rectangle.stack.person.crop")
                    Text("Contacts")
                }
            
            SearchDatabase()
                .tabItem { Image(systemName: "magnifyingglass.circle.fill")
                    Text("Search Contacts")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
