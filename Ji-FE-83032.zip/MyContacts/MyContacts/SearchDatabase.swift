//
//  SearchDatabase.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI
import CoreData

var searchCategory = ""
var searchQuery = ""
struct SearchDatabase: View {
    
    let  searchCategoriesList = ["All","First Name", "Last Name", "Company Name", "Notes", "City Name", "State Abbreviation", "Country Name"]
    @State private var selectedSearchCategoryIndex = 3
    @State private var searchFieldValue = ""
    var body: some View {
        NavigationView {
            Form {
                Section() {
                    
                    HStack(alignment:.center) {
                        Spacer()
                        Image("SearchDatabase")
                            .resizable()
                            //.aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                            
                        Spacer()
                    }
                    
                }
                
                Section(header: Text("select a search category")) {
                    Picker("", selection: $selectedSearchCategoryIndex) {
                        ForEach(0..<searchCategoriesList.count, id:\.self) {
                            Text(self.searchCategoriesList[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())

                }
                
                Section(header:Text("Search Query under Selected Category")) {
                    HStack {
                       TextField("Enter Search Query", text: $searchFieldValue)
                           .textFieldStyle(RoundedBorderTextFieldStyle())
                           .disableAutocorrection(true)
                           .autocapitalization(.none)

                       // Button to clear the text field
                       Button(action: {
                           self.searchFieldValue = ""
                       }) {
                           Image(systemName: "clear")
                               .imageScale(.medium)
                               .font(Font.title.weight(.regular))
                       }
                   }   // End of HStack
                   .padding(.horizontal)
                }
                
                
                Section(header: Text("show search results")) {
                    NavigationLink(destination: showSearchResults()) {
                        HStack {
                            Image(systemName: "list.bullet")
                            Text("Show Search Results")
                                .font(.headline)
                        }
                    }
                }
            }
            .navigationBarTitle(Text("Search Core Data Database"),displayMode: .inline)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
    
    
    func showSearchResults() -> some View {
        let queryTrimmed = self.searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if (queryTrimmed.isEmpty) {
            return AnyView(missingSearchQueryMessage)
        }
        
        searchCategory = self.searchCategoriesList[self.selectedSearchCategoryIndex]
        searchQuery = self.searchFieldValue
        return AnyView(ResultList())
    }
    
    var missingSearchQueryMessage: some View {
        ZStack {
            Color(red: 1.0, green: 1.0, blue: 240/250)
                .edgesIgnoringSafeArea(.all)
            VStack {
                Image(systemName: "exclamationmark.triangle")
                    .imageScale(.large)
                    .font(Font.title.weight(.medium))
                    .foregroundColor(.red)
                    .padding()
                Text("Search Query Missing!\nPlease enter a search query to be able to search the database!")
                    .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        }
    }
}

struct SearchDatabase_Previews: PreviewProvider {
    static var previews: some View {
        SearchDatabase()
    }
}
