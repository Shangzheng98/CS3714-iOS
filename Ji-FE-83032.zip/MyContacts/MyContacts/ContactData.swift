//
//  ContactData.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//

import Foundation
import CoreData
import SwiftUI

fileprivate var contactStructList = [ContactStruct]()

public func createContactsDatabase() {
 
    contactStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: "ContactsData.json", fileLocation: "Main Bundle")
   
    populateDatabase()
}

func populateDatabase() {
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    let fetchRequest = NSFetchRequest<Contact>(entityName: "Contact")
        fetchRequest.sortDescriptors = [
            // Primary sort key: artistName
            NSSortDescriptor(key: "lastName", ascending: true),
            // Secondary sort key: songName
            NSSortDescriptor(key: "firstName", ascending: true)
        ]
    
    var listOfAllSongEntitiesInDatabase = [Contact]()
    
    do {
           //-----------------------------
           // ❎ Execute the Fetch Request
           //-----------------------------
           listOfAllSongEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("Populate Database Failed!")
        return
    }
    if listOfAllSongEntitiesInDatabase.count > 0 {
        // Database has already been populated
        print("Database has already been populated!")
        return
    }
    
    for contact in contactStructList {
        let contactEntry = Contact(context: managedObjectContext)
        
        contactEntry.lastName = contact.lastName
        contactEntry.firstName = contact.firstName
        contactEntry.notes = contact.notes
        contactEntry.url = contact.url
        contactEntry.email = contact.email
        contactEntry.phone = contact.phone
        
        let photoEentry = Photo(context: managedObjectContext)
        
        let photoUIImage = UIImage(named: contact.photoFullFilename)
        
        let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
        photoEentry.contactPhoto = photoData!
        
        contactEntry.company = contact.company
        contactEntry.addressLine1 = contact.addressLine1
        contactEntry.addressLine2 = contact.addressLine2
        contactEntry.addressState = contact.addressState
        contactEntry.addressCity = contact.addressCity
        contactEntry.addressCountry = contact.addressCountry
        contactEntry.addressZipcode = contact.addressZipcode
        
        contactEntry.photo = photoEentry
        photoEentry.contact = contactEntry
        do {
            try managedObjectContext.save()
        } catch {
            return
        }
    }
    
    
}
