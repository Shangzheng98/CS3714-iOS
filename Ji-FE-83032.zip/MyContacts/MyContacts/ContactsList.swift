//
//  ContactsList.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI

struct ContactsList: View {
    
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(fetchRequest: Contact.allContactsFetchRequest()) var allContacts: FetchedResults<Contact>
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        NavigationView {
            List {
                ForEach(self.allContacts) {
                    aContact in NavigationLink(destination: ContactDetails(contact: aContact)) {
                        ContactslistItem(contact: aContact)
                    }
                }
                .onDelete(perform: delete)
            }
            .navigationBarTitle(Text("Contacts"), displayMode: .inline)
            .navigationBarItems(leading: EditButton(), trailing:
                            NavigationLink(destination: AddContact()) {
                                Image(systemName: "plus")
                            })
        }
        .navigationViewStyle(StackNavigationViewStyle())
        

    }
    func delete(at offsets: IndexSet) {
        let contactToDelete = self.allContacts[offsets.first!]
        self.managedObjectContext.delete(contactToDelete)
        do {
            try self.managedObjectContext.save()
            
        } catch {
            print("unable to delete selected contact!")
        }
    }
}

struct ContactsList_Previews: PreviewProvider {
    static var previews: some View {
        ContactsList()
    }
}
