//
//  ContactDetails.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI

struct ContactDetails: View {
    
    let contact: Contact
    
    @FetchRequest(fetchRequest: Contact.allContactsFetchRequest()) var allContacts: FetchedResults<Contact>
    var body: some View {
        Form {
            Section(header: Text("change this contact's attributes")) {
                NavigationLink(destination: changeContact(contact: contact)) {
                    HStack {
                        Image(systemName: "pencil.circle")
                            .imageScale(.medium)
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                        Text("Change Contact")
                    }
                }
            }
            
            Section(header: Text("Name")) {
                Text("\(contact.firstName ?? "") \(contact.lastName ?? "")")
                
            }
            
            Section(header: Text("photo")) {
                getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
            }
            
            Section(header: Text("company name")) {
                Text(contact.company ?? "")
            }
            
            Section(header: Text("phone number")) {
                HStack {
                    Image(systemName: "phone.circle")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                        .foregroundColor(.blue)
                    Text(contact.phone ?? "")
                    
                }
            }
            
            Section(header: Text("email address")) {
                HStack {
                    Image(systemName: "envelope")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                        .foregroundColor(.blue)
                    Text(contact.email ?? "")
                }
            }
            
            Section(header: Text("website url")){
                if URL(string: contact.url!) == nil {
                    HStack {
                        EmptyView()
                    }
                    
                } else {
                    Link(destination: URL(string: contact.url!)!)
                    {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.light))
                                .foregroundColor(.blue)
                            
                            Text("Show Contact's Websit")
                            
                        }
                    }
                }
                
//                if contact.url!== nil {
//                    Link(destination: URL(string: "https://404.com")!)
//                    {
//                        HStack {
//                            Image(systemName: "globe")
//                                .imageScale(.medium)
//                                .font(Font.title.weight(.light))
//                                .foregroundColor(.blue)
//
//                            Text("Show Contact's Websit")
//
//                        }
//                    }
//                } else {
//                    Link(destination: URL(string: contact.url!)!)
//                    {
//                        HStack {
//                            Image(systemName: "globe")
//                                .imageScale(.medium)
//                                .font(Font.title.weight(.light))
//                                .foregroundColor(.blue)
//
//                            Text("Show Contact's Websit")
//
//                        }
//                    }
//                }
                
                
            }
            
            
            Section(header:Text("Notes")) {
                Text(contact.notes ?? "")
                    .multilineTextAlignment(.leading)
            }
            
            
            Section(header: Text("postal address")) {
                VStack(alignment:.leading){
                Text(contact.addressLine1 ?? "")
                if contact.addressLine2 != nil {
                    Text(contact.addressLine2!)
                }
                if contact.addressState == nil{
                    Text("\(contact.addressCity ?? ""), \(contact.addressZipcode ?? "")")
                }else {
                    Text("\(contact.addressCity ?? ""), \(contact.addressState ?? ""), \(contact.addressZipcode ?? "")")
                }
                    Text(contact.addressCountry ?? "")
                }
            }
        }
        .navigationBarTitle(Text("Contact Details"),displayMode: .inline)
    }
}
