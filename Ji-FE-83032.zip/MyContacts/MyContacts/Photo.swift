//
//  Photo.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import Foundation
import CoreData
 
/*
 🔴 Set Current Product Module:
    In xcdatamodeld editor, select Photo, show Data Model Inspector, and
    select Current Product Module from Module menu.
 🔴 Turn off Auto Code Generation:
    In xcdatamodeld editor, select Photo, show Data Model Inspector, and
    select Manual/None from Codegen menu.
*/
 
// ❎ CoreData Photo entity public class
public class Photo: NSManagedObject, Identifiable {
 
    @NSManaged public var contactPhoto: Data?
    @NSManaged public var contact: Contact?
}
