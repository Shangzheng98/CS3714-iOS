//
//  ResultList.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI

struct ResultList: View {
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(fetchRequest: Contact.filteredContactsFetchRequest(searchCategory: searchCategory, searchQuery: searchQuery)) var filteredContracts: FetchedResults<Contact>
    var body: some View {
        if self.filteredContracts.isEmpty {
            SearchResultsEmpty()
        }
        else {
            List {
                ForEach(self.filteredContracts) {
                    aContact in NavigationLink(destination:ContactDetails(contact: aContact)) {
                        ContactslistItem(contact: aContact)
                    }
                }
            }
            .navigationBarTitle(Text("Contacts Found"), displayMode: .inline)
        }
    }
}

struct ResultList_Previews: PreviewProvider {
    static var previews: some View {
        ResultList()
    }
}
