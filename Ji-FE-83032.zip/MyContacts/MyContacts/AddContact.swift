//
//  AddContact.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI
import CoreData

struct AddContact: View {
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.presentationMode) var presentationMode
    @State private var showContactAddedAlert = false
    @State private var showInputDataMissingAlert = false
    
    @State private var firstName = ""
    @State private var lastName  = ""
    @State private var company   = ""
    @State private var phone  = ""
    @State private var email  = ""
    @State private var url = ""
    @State private var notes  = ""
    @State private var addressLine1  = ""
    @State private var addressLine2  = ""
    @State private var addressCity  = ""
    @State private var addressState  = ""
    @State private var addressZipcode  = ""
    @State private var addressCountry  = ""
    
    var photoTakeOrPickChoices = ["Camera", "Photo Library"]
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var photoTakeOrPickIndex = 1     // Pick from Photo Library
    var body: some View {
        Form {
            Group {
                Section(header: Text("first name")) {
                    HStack {
                        TextField("Enter first name", text: $firstName)
                        
                        Button(action: {
                            self.firstName = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                Section(header: Text("last name")) {
                    HStack {
                        TextField("Enter last name", text: $lastName)
                        
                        Button(action: {
                            self.lastName = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                Section(header: Text("company name")) {
                    HStack {
                        TextField("Enter company name", text: $company)
                        
                        Button(action: {
                            self.company = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                Section(header: Text("phone name")) {
                    HStack {
                        TextField("Enter phone name", text: $phone)
                        
                        Button(action: {
                            self.phone = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                
                Section(header: Text("email name")) {
                    HStack {
                        TextField("Enter email name", text: $email)
                        
                        Button(action: {
                            self.email = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                
                Section(header: Text("website url")) {
                    HStack {
                        TextField("Enter website URL", text: $url)
                        
                        Button(action: {
                            self.url = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                
                
                Section(header: Text("contact Notes"), footer:
                    Button(action: {
                        self.dismissKeyboard()
                    }) {
                        Image(systemName: "keyboard")
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                    }
                ) {
                    TextEditor(text: $notes)
                    .frame(height: 100)
                    .font(.custom("Helvetica", size: 14))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    
                }
                
                Section(header:Text("add contact photo")) {
                    VStack {
                        Picker("Take or Pick Photo", selection: $photoTakeOrPickIndex) {
                            ForEach(0 ..< photoTakeOrPickChoices.count, id: \.self) {
                                Text(self.photoTakeOrPickChoices[$0])
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding()
                       
                        Button(action: {
                            self.showImagePicker = true
                        }) {
                            Text("Get Photo")
                                .padding()
                        }
                        Spacer()
                        
                        
                    }
                }
                
                Section(header: Text("contact photo")) {
                    getImageFromBinaryData(binaryData:self.photoImageData, defaultFilename: "DefaultContactPhoto")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                }
                
                
                
                
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .alert(isPresented: $showInputDataMissingAlert, content: {
                self.inputDataMissingAlert
            })
            Group {
                Section(header: Text("address line 1")) {
                    HStack {
                        TextField("Enter address line 1", text: $addressLine1)
                        
                        Button(action: {
                            self.addressLine1 = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                
                Section(header: Text("address line 2")) {
                    HStack {
                        TextField("Enter address line 2", text: $addressLine2)
                        
                        Button(action: {
                            self.addressLine2 = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                Section(header: Text("city name")) {
                    HStack {
                        TextField("Enter city name", text: $addressCity)
                        
                        Button(action: {
                            self.addressCity = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                Section(header: Text("State abbreviation")) {
                    HStack {
                        TextField("Enter State abbreviation", text: $addressState)
                        
                        Button(action: {
                            self.addressState = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                
                Section(header: Text("zip code")) {
                    HStack {
                        TextField("Enter zip code", text: $addressZipcode)
                        
                        Button(action: {
                            self.addressZipcode = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
                Section(header: Text("country name")) {
                    HStack {
                        TextField("Enter country name", text: $addressCountry)
                        
                        Button(action: {
                            self.addressCountry = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }
                    
                }
                
            }
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .alert(isPresented: $showContactAddedAlert, content: {
                self.contactAddedAlert
            })
        }
        .font(.system(size: 14))
        .sheet(isPresented: self.$showImagePicker) {
            PhotoCaptureView(showImagePicker: self.$showImagePicker,
                             photoImageData: self.$photoImageData,
                             cameraOrLibrary: self.photoTakeOrPickChoices[self.photoTakeOrPickIndex])
        
        }
        .disableAutocorrection(true)
        .autocapitalization(.words)
        .navigationBarTitle(Text("Add Contact"), displayMode: .inline)
        .navigationBarItems(trailing: Button (action: {
            if !self.firstName.isEmpty && !self.lastName.isEmpty && !self.phone.isEmpty && !self.email.isEmpty && !self.addressLine1.isEmpty && !self.addressCity.isEmpty && !self.addressCountry.isEmpty {
                let newContact = Contact(context: self.managedObjectContext)
                
                newContact.firstName = self.firstName
                newContact.lastName = self.lastName
                newContact.company = self.company
                newContact.phone = self.phone
                newContact.email = self.email
                newContact.url = self.url
                newContact.notes = self.notes
                newContact.addressLine1 = self.addressLine1
                newContact.addressLine2 = self.addressLine2
                newContact.addressCity = self.addressCity
                newContact.addressState = self.addressState
                newContact.addressZipcode = self.addressZipcode
                newContact.addressCountry = self.addressCountry
                
                let newPhoto = Photo(context: self.managedObjectContext)
                if let imageData = self.photoImageData {
                    newPhoto.contactPhoto = imageData
                } else {
                    let photoUIImage = UIImage(named: "DefaultContactPhoto")
                    
                    let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
                    newPhoto.contactPhoto = photoData!
                }
                newContact.photo = newPhoto
                newPhoto.contact = newContact
                
                do {
                    try self.managedObjectContext.save()
                    self.showContactAddedAlert = true
                } catch {
                    return
                }
            } else {
                self.showInputDataMissingAlert = true
            }
        }) {
            Text("Save")
        })
    }
    
    func dismissKeyboard() {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        
    }
    
    var contactAddedAlert: Alert {
        Alert(title: Text("contact Added!"),
              message: Text("New contact is added to your Contacts list."),
              dismissButton: .default(Text("OK")) {
                  // Dismiss this View and go back
                  self.presentationMode.wrappedValue.dismiss()
            })
    }
    
    var inputDataMissingAlert: Alert {
        Alert(title: Text("Missing Input Data!"),
              message: Text("Required Data: first name, last name, phone, email, address line 1, city, and country."),
              dismissButton: .default(Text("OK")) )
    }
    
}

struct AddContact_Previews: PreviewProvider {
    static var previews: some View {
        AddContact()
    }
}
