//
//  changeContact.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI

struct changeContact: View {
    let contact: Contact
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) var managedObjectContext
    @State private var showChangesSavedAlert = false
    
    @State private var firstName = ""
    @State private var lastName  = ""
    @State private var company   = ""
    @State private var phone  = ""
    @State private var email  = ""
    @State private var url = ""
    @State private var notes  = ""
    @State private var addressLine1  = ""
    @State private var addressLine2  = ""
    @State private var addressCity  = ""
    @State private var addressState  = ""
    @State private var addressZipcode  = ""
    @State private var addressCountry  = ""
    
    
    @State private var changefirstName = false
    @State private var changelastName  = false
    @State private var changephotoFullFilename   = false
    @State private var changecompany   = false
    @State private var changephone  = false
    @State private var changeemail  = false
    @State private var changeurl = false
    @State private var changenotes  = false
    @State private var changeaddressLine1  = false
    @State private var changeaddressLine2  = false
    @State private var changeaddressCity  = false
    @State private var changeaddressState  = false
    @State private var changeaddressZipcode  = false
    @State private var changeaddressCountry  = false
    
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var photoTakeOrPickIndex = 1     // Take using camera
    
    var photoTakeOrPickChoices = ["Camera", "Photo Library"]
    
    var body: some View {
        Form {
            Group {
                Section (header: Text("first Name")) {
                    VStack {
                        HStack {
                            Text(contact.firstName ?? "")
                            Button(action: {
                                self.changefirstName.toggle()
                            }) {
                                if self.changefirstName {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                    
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changefirstName {
                            TextField("Change first name", text: $firstName)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                Section (header: Text("last Name")) {
                    VStack {
                        HStack {
                            Text(contact.lastName ?? "")
                            Button(action: {
                                self.changelastName.toggle()
                            }) {
                                if self.changelastName {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changelastName {
                            TextField("Change last name", text: $lastName)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                Section (header: Text("company Name")) {
                    VStack {
                        HStack {
                            Text(contact.company ?? "")
                            Button(action: {
                                self.changecompany.toggle()
                            }) {
                                if self.changecompany {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changecompany {
                            TextField("Change company name", text: $company)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                Section (header: Text("Phone number")) {
                    VStack {
                        HStack {
                            Text(contact.phone ?? "")
                            Button(action: {
                                self.changephone.toggle()
                            }) {
                                if self.changephone {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changephone {
                            TextField("Change phone number", text: $phone)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                Section (header: Text("email address")) {
                    VStack {
                        HStack {
                            Text(contact.email ?? "")
                            Button(action: {
                                self.changeemail.toggle()
                            }) {
                                if self.changeemail {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeemail {
                            TextField("Change email address", text: $email)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                Section (header: Text("website url")) {
                    VStack {
                        HStack {
                            Text(contact.url ?? "")
                            Button(action: {
                                self.changeurl.toggle()
                            }) {
                                if self.changeurl {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeurl {
                            TextField("Change website url", text: $url)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                Section (header: Text("contact notes")) {
                    HStack {
                        Text(contact.notes ?? "")
                        Button(action: {
                            self.changenotes.toggle()
                        }) {
                            if self.changenotes {
                                Image(systemName: "xmark.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            } else {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                            
                        }
                    }
                }
                if self.changenotes {
                    Section(header: Text("contact Notes"), footer:
                        Button(action: {
                            self.dismissKeyboard()
                        }) {
                            Image(systemName: "keyboard")
                                .font(Font.title.weight(.light))
                                .foregroundColor(.blue)
                        }
                    ) {
                        TextEditor(text: $notes)
                        .frame(height: 100)
                        .font(.custom("Helvetica", size: 14))
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                        
                    }
                }
                
                Section (header: Text("contact photo")) {
                    HStack {
                        getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100, height: 100)
                        
                        Button(action: {
                            self.changephotoFullFilename.toggle()
                        }) {
                            if self.changephotoFullFilename {
                                Image(systemName: "xmark.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            } else {
                                Image(systemName: "pencil.circle")
                                    .imageScale(.small)
                                    .font(Font.title.weight(.light))
                                    .foregroundColor(.blue)
                            }
                            
                        }
                    }
                }
            }
            
            Group {
                if self.changephotoFullFilename {
                    Section(header:Text("new contact photo")) {
                        VStack {
                            Picker("Take or Pick Photo", selection: $photoTakeOrPickIndex) {
                                ForEach(0 ..< photoTakeOrPickChoices.count, id: \.self) {
                                    Text(self.photoTakeOrPickChoices[$0])
                                }
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .padding()
                           
                            Button(action: {
                                self.showImagePicker = true
                            }) {
                                Text("Get Photo")
                                    .padding()
                            }
                            Spacer()
                            
                            getImageFromBinaryData(binaryData:self.photoImageData, defaultFilename: "DefaultContactPhoto")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 100, height: 100)
                        }
                    }
                }
                Section (header: Text("address line 1")) {
                    VStack {
                        HStack {
                            Text(contact.addressLine1 ?? "")
                            Button(action: {
                                self.changeaddressLine1.toggle()
                            }) {
                                if self.changeaddressLine1 {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        if self.changeaddressLine1 {
                            TextField("Change address line 1", text: $addressLine1)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        
                    }
                    
                }
                
                Section (header: Text("address line 2")) {
                    
                    VStack {
                        HStack {
                            Text(contact.addressLine2 ?? "")
                            Button(action: {
                                self.changeaddressLine2.toggle()
                            }) {
                                if self.changeaddressLine2 {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeaddressLine2 {
                            TextField("Change address line 2", text: $addressLine2)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                
            }
            
            
            Group {
                Section (header: Text("city name")) {
                    VStack {
                        HStack {
                            Text(contact.addressCity ?? "")
                            Button(action: {
                                self.changeaddressCity.toggle()
                            }) {
                                
                                if self.changeaddressCity {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeaddressCity {
                            TextField("Change city name", text: $addressCity)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                
                Section (header: Text("State abbreviation")) {
                    VStack {
                        HStack {
                            Text(contact.addressState ?? "")
                            Button(action: {
                                self.changeaddressState.toggle()
                            }) {
                                if self.changeaddressState {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeaddressState {
                            TextField("Change state abbreviation", text: $addressState)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                Section (header: Text("zip code")) {
                    VStack {
                        HStack {
                            Text(contact.addressZipcode ?? "")
                            Button(action: {
                                self.changeaddressZipcode.toggle()
                            }) {
                                
                                if self.changeaddressZipcode {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeaddressZipcode {
                            TextField("Change Zip Code", text: $addressZipcode)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
                
                Section (header: Text("country name")) {
                    VStack {
                        HStack {
                            Text(contact.addressCountry ?? "")
                            Button(action: {
                                self.changeaddressCountry.toggle()
                            }) {
                                
                                if self.changeaddressCountry {
                                    Image(systemName: "xmark.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                } else {
                                    Image(systemName: "pencil.circle")
                                        .imageScale(.small)
                                        .font(Font.title.weight(.light))
                                        .foregroundColor(.blue)
                                }
                                
                            }
                        }
                        
                        if self.changeaddressCountry {
                            TextField("Change country name", text: $addressCountry)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                    }
                    
                }
            }
        }
        .font(.system(size: 14))
        .alert(isPresented: $showChangesSavedAlert, content: { self.changesSavedAlert })
        .disableAutocorrection(true)
        .autocapitalization(.words)
        .navigationBarTitle(Text("Change Contact"), displayMode: .inline)
        .navigationBarItems(trailing:
            Button(action: {
                if self.changesMade() {
                    self.saveChanges()
                }
                // Show changes saved or no changes saved alert
                self.showChangesSavedAlert = true
            }) {
                Text("Save")
            })
        .sheet(isPresented: self.$showImagePicker) {
            PhotoCaptureView(showImagePicker: self.$showImagePicker,
                             photoImageData: self.$photoImageData,
                             cameraOrLibrary: self.photoTakeOrPickChoices[self.photoTakeOrPickIndex])
        }
    }
    func changesMade() -> Bool {
           
        if self.firstName.isEmpty && self.lastName.isEmpty && self.phone.isEmpty && self.url.isEmpty && self.email.isEmpty && self.photoImageData == nil && self.company.isEmpty && self.notes.isEmpty && self.addressLine1.isEmpty && self.addressLine2.isEmpty && self.addressCity.isEmpty && self.addressState.isEmpty && self.addressZipcode.isEmpty && self.addressCountry.isEmpty {
                return false
            }
            return true
        }
    func dismissKeyboard() {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        
    }
    func saveChanges() {
        // Change Song attributes if updated
       
        if self.firstName != "" {
            contact.firstName = self.firstName
        }
        if self.lastName != "" {
            contact.lastName = self.lastName
        }
        if self.company != "" {
            contact.company = self.company
        }
        if self.phone != "" {
            contact.phone = self.phone
        }
        if self.email != "" {
           
            contact.email = self.email
        }
        if self.url != "" {
            contact.url = self.url
        }
        if self.photoImageData != nil {
            if let imageData = self.photoImageData {
                contact.photo!.contactPhoto! = imageData
            } else {
                // Obtain the album cover default image from Assets.xcassets as UIImage
                let photoUIImage = UIImage(named: "DefaultContactPhoto")
               
                // Convert photoUIImage to data of type Data (Binary Data) in JPEG format with 100% quality
                let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
               
                // Assign photoData to Core Data entity attribute of type Data (Binary Data)
                contact.photo!.contactPhoto! = photoData!
            }
        }
        
        if self.notes != "" {
            contact.notes = self.notes
        }
        
        if self.addressLine1 != "" {
            contact.addressLine1 = self.addressLine1
        }
        
        if self.addressLine2 != "" {
            contact.addressLine2 = self.addressLine2
        }
        
        if self.addressCity != "" {
            contact.addressCity = self.addressCity
        }
        
        if self.addressState != "" {
            contact.addressState = self.addressState
        }
        
        if self.addressZipcode != "" {
            contact.addressZipcode = self.addressZipcode
        }
        
        if self.addressCountry != "" {
            contact.addressCountry = self.addressCountry
        }
        
        
        do {
            try self.managedObjectContext.save()
        } catch {
            return
        }
    }
    var changesSavedAlert: Alert {
       
        if changesMade() {
            return Alert(title: Text("Changes Saved!"),
              message: Text("Your changes have been successfully saved to the database."),
              dismissButton: .default(Text("OK")) {
                  self.presentationMode.wrappedValue.dismiss()
                })
        }
 
        return Alert(title: Text("No Changes Saved!"),
          message: Text("You did not make any changes!"),
          dismissButton: .default(Text("OK")) {
              self.presentationMode.wrappedValue.dismiss()
            })
    }
}

