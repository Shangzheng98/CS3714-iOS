//
//  ContactslistItem.swift
//  MyContacts
//
//  Created by Shangzheng Ji on 12/7/20.
//  Copyright © 2020 Shangzheng Ji. All rights reserved.
//

import SwiftUI

struct ContactslistItem: View {
    let contact: Contact
    var body: some View {
        HStack {
            getImageFromBinaryData(binaryData: contact.photo!.contactPhoto!, defaultFilename: "DefaultContactPhoto")
                .resizable()
                .frame(width: 80, height: 80)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white, lineWidth: 1))
                .shadow(radius: 5)
            
            VStack (alignment: .leading){
                Text("\(contact.firstName ?? "") \(contact.lastName ?? "")")
                HStack {
                    Image(systemName: "phone.circle")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                    Text(contact.phone ?? "")
                    
                }
                HStack {
                    Image(systemName: "envelope")
                        .imageScale(.medium)
                        .font(Font.title.weight(.light))
                    Text(contact.email ?? "")
                }
            }
        }
        
    }
    
    
}

